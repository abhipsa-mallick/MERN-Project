// classical components or class component

import React, { Component } from "react";

class HelloWorldClass extends Component{
    render(){
        return(
            <div>
                <h2>Hello World By Class Component</h2>
            </div>
        );
    }
}

export default HelloWorldClass
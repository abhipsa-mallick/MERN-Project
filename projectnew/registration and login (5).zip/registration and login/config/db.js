const mongoose = require('mongoose');
 
exports.dbConn = async ()=>{
    try{
        const dbURL = "mongodb+srv://mallickabhipsa:mongo11840@cluster0.izgvc.mongodb.net/productdb?retryWrites=true&w=majority"; 
        await mongoose.connect(dbURL,{useNewUrlParser:true,useUnifiedTopology:true})
        console.log('Database Connected');
    }
    catch(err){
        console.log(`Database connection error ${err.message}`);
    } 
}